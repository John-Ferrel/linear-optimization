# linear-programming
interior point method for linear programming 
See the link below for a program documentation(in Chinese): 
https://github.com/PrimerLi/linear-programming/blob/master/%E5%87%B8%E4%BC%98%E5%8C%96%E7%AE%97%E6%B3%95%20I:%20%E5%86%85%E7%82%B9%E6%B3%95(interior%20point%20method)%E6%B1%82%E8%A7%A3%E7%BA%BF%E6%80%A7%E8%A7%84%E5%88%92%E9%97%AE%E9%A2%98.pdf

